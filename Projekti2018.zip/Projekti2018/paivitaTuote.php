<!DOCTYPE HTML>
<html>
<head>
    <title>Päivitä tuote - PC-huolto</title>
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
		 
</head>
<body>
  
    <div class="container">
  
        <div class="page-header">
            <h1>Päivitä tuote</h1>
        </div>
<?php

//yhteys tietokantaan
include 'YhteysTietokantaanNJAdmin.php';
 
?>
 
 <?php
 
if($_POST){
	
    try{
    
        $paivitysKomento = "UPDATE Tuote 
                    SET TuoteNimi=:TuoteNimi, TuoteHinta=:TuoteHinta 
                    WHERE TuoteID = :TuoteID";
 
        // prepare query for excecution
        $sqlLause = $yhteys->prepare($paivitysKomento);
 
        // posted values
		$TuoteID=htmlspecialchars(strip_tags($_POST['TuoteID']));
        $TuoteNimi=htmlspecialchars(strip_tags($_POST['TuoteNimi']));
        $TuoteHinta=htmlspecialchars(strip_tags($_POST['TuoteHinta']));
 
        // bind the parameters
        $sqlLause->bindParam(':TuoteNimi', $TuoteNimi);
        $sqlLause->bindParam(':TuoteHinta', $TuoteHinta);
        $sqlLause->bindParam(':TuoteID', $TuoteID);
        $sqlLause->execute();
		$lukumaara = $sqlLause->rowCount();
        // Execute the query
        if($lukumaara > 0){
            echo "<div class='alert alert-success'>Tuote on päivitetty.</div>";
        }else{
            echo "<div class='alert alert-danger'>Tuotetta ei päivitetty.</div>";
        }
         
    }
     
    // show errors
    catch(PDOException $exception){
        die('ERROR: ' . $exception->getMessage());
    }
}
?>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="post">
    <table class='table table-hover table-responsive table-bordered'>
        <tr>
            <td>Tuotekoodi</td>
            <td><input type='text' rows=1 cols=50 maxlength=5 name='TuoteID' class='form-control' required></td>
        </tr>
        <tr>
            <td>Tuotteen nimi</td>
            <td><textarea name='TuoteNimi' rows=3 cols=50 maxlength=100 class='form-control' required> </textarea></td>
        </tr>
		
        <tr>
            <td>Tuotteen hinta</td>
            <td><input type='text' rows=1 cols=50 maxlength=10 name='TuoteHinta' class='form-control' required></td>
        </tr>
        <tr>
            <td>
                <a href='Etusivu.php' class='btn btn-danger'>Takaisin etusivulle</a>
            </td>
			<td>
				<input type='submit' value='Tallenna muutokset' class='btn btn-primary' />
            </td>
        </tr>
    </table>
</form>
          
 </div>

<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
</body>
</html>