<?php

    if (isset($_GET["HuollonOsatID"]))
    {
        $HuollonOsatID = $_GET["HuollonOsatID"];
    }
    else
    {
        die('ERROR: Osaa ei löydy.');
    }
//$id=isset($_GET['id']) ? $_GET['id'] : die('ERROR: Record ID not found.');
 
include 'YhteysTietokantaanNJAdmin.php';

// 
try {
    // prepare select query
    $query = "DELETE FROM HuollonOsat WHERE HuollonOsatID = :HuollonOsatID ";
    $stmt = $yhteys->prepare( $query );
 
    // Sidotaan saatu osastotunnus kyselyyn
    $stmt->bindParam(':HuollonOsatID', $HuollonOsatID);
 
 
    // suorita haku
    $stmt->execute();
    $lukumaara = $stmt->rowCount();
    if ($lukumaara  === 0)
    {
        die('ERROR: Osia löytyy nolla.');
    }
	else
	{
		echo "Poisto onnistui.";
	}

}
 
// show error
catch(PDOException $exception){
    die('ERROR: ' . $exception->getMessage());
}
?>
 
<table class='table table-hover table-responsive table-bordered'>
    <tr>
        <td>
            <a href='PoistaHuollonOsa.php' class='btn btn-danger'>Takaisin etusivulle</a>
        </td>
    </tr>
</table>