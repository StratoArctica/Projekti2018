<!DOCTYPE HTML>
<html>
<head>
    <title>PC-huolto etusivu</title>
     
    <link rel="stylesheet" 
	href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
         
    <style>
    .m-r-1em{ margin-right:1em; }
    .m-b-1em{ margin-bottom:1em; }
    .m-l-1em{ margin-left:1em; }
    .mt0{ margin-top:0; }
    </style>
</head>
<body>
    <div class="container">
  
        <div class="page-header">
            <h1>PC-huolto Etusivu</h1>
        </div>
 <?php
  include 'YhteysTietokantaanNJAdmin.php';

?>
     	 <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
    <table class='table table-hover table-responsive table-bordered'>
        <tr>
          <td> <a href='lisaaHuollonOsa.php' class='btn btn-primary'>Lisää huollonosa</a> </td>
		  <td> <a href='paivitaTuote.php' class='btn btn-primary'>Päivitä tuote</a> </td>
		  <td> <a href='PoistaHuollonOsa.php' class='btn btn-primary'>Poista huollonosa</a> </td>
        </tr>
    </table>
</form>    
 </div>
     
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
</body>
</html>