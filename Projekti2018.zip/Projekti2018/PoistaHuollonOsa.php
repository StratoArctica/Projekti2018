<!DOCTYPE HTML>
<html>
<head>
    <title>Poista huollonosa</title>
     
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" 
	href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
         
    <style>
    .m-r-1em{ margin-right:1em; }
    .m-b-1em{ margin-bottom:1em; }
    .m-l-1em{ margin-left:1em; }
    .mt0{ margin-top:0; }
    </style>
</head>
<body>
    <div class="container">
  
        <div class="page-header">
            <h1>Poista huollonosa</h1>
        </div>
 <?php
  include 'YhteysTietokantaanNJAdmin.php';
 
  $sqlLause = "SELECT HuollonOsatID, HuoltoVarausID, TuoteID, KplMaara, MyyntiHinta FROM HuollonOsat WHERE huoltovarausID = '00001'";
  $komento = $yhteys->prepare($sqlLause);
  $komento->execute();
 
  // palautettujen rivien lukumäärä saadaan näin
  $num = $komento->rowCount();
 
  //check if more than 0 record found
  if($num>0){
 
    echo "<table class='table table-hover table-responsive table-bordered'>";//start table
 
    echo "<tr>";
    echo "<th>Huolto-osakoodi</th>";
	echo "<th>Huoltovarauskoodi</th>";
	echo "<th>Tuotekoodi</th>";
    echo "<th>Kappalemäärä</th>";
    echo "</tr>";
	

  while ($rivi = $komento->fetch(PDO::FETCH_ASSOC)){
	 // extract muuttaa
     extract($rivi);
     
     // tehdään jokaisesta HuollonOsat -taulun rivistä oma rivi tauluun
        echo "<tr>";
        echo "<td>{$HuollonOsatID}</td>";
		echo "<td>{$HuoltoVarausID}</td>";
		echo "<td>{$TuoteID}</td>";
		echo "<td>{$KplMaara}</td>";
        echo "<td>";
            echo "<a href='PoistaYksiHuollonOsa.php?HuollonOsatID={$HuollonOsatID}' class='btn btn-danger'>Poista osa</a>";
        echo "</td>";
		
    echo "</tr>";
}
echo "</table>"; 
}
 
// jos ei löytynyt mitään

else{
    echo "<div class='alert alert-danger'>Osia ei löytynyt.</div>";
}
?>
      <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="post">
    <table class='table table-hover table-responsive table-bordered'>
        <tr>
            <a href='Etusivu.php' class='btn btn-danger'>Takaisin etusivulle</a>
        </tr>
</table>
</form>		
 </div>
     
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 
</body>
</html>