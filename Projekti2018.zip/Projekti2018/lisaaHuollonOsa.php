<!DOCTYPE HTML>
<html>
<head>
    <title>Lisää huollon osa - PC-huolto</title>
      
    <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" />
          
</head>
<body>
  
<div class="container">
   
        <div class="page-header">
            <h1>Lisää huollonosa</h1>
        </div>
<?php

	if($_POST){
        
    // include hakee yhteyden tietokantaan, jossa on osasto-taulu, yhteys-objektille on annettu nimi $yhteys
    include 'YhteysTietokantaanNJAdmin.php';
 
    try{
		// tehdään insert eli tietorivin lisääminen tietokantaan
		// insert-kysely muodostetaan käyttäen nimettyjä parametreja
		// lisättävien tietojen sijalla
		$lisaysKomento = "INSERT INTO HuollonOsat SET HuollonOsatID = :HuollonOsatID, HuoltoVarausID = :HuoltoVarausID, TuoteID = :TuoteID, KplMaara = :KplMaara, MyyntiHinta = :MyyntiHinta";
        $sqlLause = $yhteys->prepare($lisaysKomento);
		
		// haetaan käyttäjän antamat tiedot ja putsataan ne laittomuuksista
		$HuollonOsatID = htmlspecialchars(($_POST["HuollonOsatID"]));
		$HuoltoVarausID = htmlspecialchars(($_POST["HuoltoVarausID"]));
		$TuoteID = htmlspecialchars(($_POST["TuoteID"]));
		$KplMaara = htmlspecialchars(($_POST["KplMaara"]));
		$MyyntiHinta = htmlspecialchars(($_POST["MyyntiHinta"]));
		
		// laitetaan käyttäjän antamat tiedot nimettyjen parametrien tilalle
		$sqlLause->bindParam(':HuollonOsatID', $HuollonOsatID);
		$sqlLause->bindParam(':HuoltoVarausID', $HuoltoVarausID);
		$sqlLause->bindParam(':TuoteID', $TuoteID);
		$sqlLause->bindParam(':KplMaara', $KplMaara);
		$sqlLause->bindParam(':MyyntiHinta', $MyyntiHinta);
		
		// suorita kysely käyttäjän antamilla tiedoilla
		if ($sqlLause->execute()){
			echo "<div class = 'alert alert-success'>Huoltotieto on lisätty.</div>";
		} else {
			echo "<div class = 'alert alert-success'>Huoltotietoa ei lisätty.</div>";
		}
    }
     
		// show error
		catch(PDOException $exception){
			die('Virhe: Vääriä tietoja annettu.' . $exception->getMessage('juu'));
    }
}
?>
	
 
<!-- html form - kutsuu itseään, eli php-koodi on tässä samassa tiedostossa tuossa yläpuolella -->
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
    <table class='table table-hover table-responsive table-bordered'>
        <tr>
            <td>Huolto-osakoodi</td>
            <td><input type='text' rows=1 cols=50 maxlength=5 name='HuollonOsatID' class='form-control' required></td>
        </tr>
		<tr>
            <td>Huoltovarauskoodi</td>
            <td><textarea name='HuoltoVarausID' rows=1 cols=50 maxlength=5 class='form-control' required></textarea></td>
        </tr>
		<tr>
            <td>Tuotekoodi</td>
            <td><textarea name='TuoteID' rows=1 cols=50 maxlength=5 class='form-control' required></textarea></td>
        </tr>
        <tr>
            <td>Kappalemäärä</td>
            <td><textarea name='KplMaara' rows=1 cols=50 maxlength=5 class='form-control' required></textarea></td>
        </tr>

		 <tr>
            <td>Myyntihinta</td>
            <td><textarea name='MyyntiHinta' rows=1 cols=15 maxlength=10 colclass='form-control' required></textarea></td>
        </tr>
		
        <tr>
            <td>
			<a href='Etusivu.php' class='btn btn-danger'>Takaisin etusivulle</a>
			</td>
            <td>
                <input type='submit' value='Lisää osa' class='btn btn-primary' />
            </td>
        </tr>
    </table>
</form>

          
 </div>
      
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
   
<!-- Latest compiled and minified Bootstrap JavaScript 
https://www.codeofaninja.com/2011/12/php-and-mysql-crud-tutorial.html
-->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  
</body>
</html>