<?php
// Tietokanta on muodostettu komennoilla, jotka loytyvat 
// Y-asemalta students/RTU/MySQL-hakemistosta tiedostosta Hovi_esimerkkikanta.sql

// muodostetaan yhteys tietokantaan
$palvelimenNimi = "mysql.cc.puv.fi";
$username = "e1701264";
$password = "naa6BWqaSpCB";
$yhteys = "";

try {
    $yhteys = new PDO("mysql:host=$palvelimenNimi;dbname=e1701264_NJAdmin", $username, $password);
    // set the PDO error mode to exception
    $yhteys->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);  
    }
catch(PDOException $e)
    {
    echo "Connection failed: " . $e->getMessage();
    }


// merkistö:  utf8
$yhteys->exec("SET NAMES utf8");

?>