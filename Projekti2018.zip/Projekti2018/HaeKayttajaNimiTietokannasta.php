<?php
// Start the session
session_start();

 $kayttajaTunnus = "";
 $kayttajaSalasana = "";
    if (isset($_POST["kayttajaTunnus"]))
    {
        $kayttajaTunnus = htmlspecialchars($_POST["kayttajaTunnus"]);
		$kayttajaSalasana = htmlspecialchars($_POST["kayttajaSalasana"]);
    }
    else
    {
        die('Haettava tieto ei tule oikein selaimelta.');
    }
 
include 'YhteysTietokantaanNJAdmin.php';

try 
  { 
    $query = "SELECT kayttajaTunnus, kayttajaSalasana FROM HenkiloKunta WHERE kayttajaTunnus = :kayttajaTunnus";
    $stmt = $yhteys->prepare( $query );
    $stmt->bindParam(':kayttajaTunnus', $kayttajaTunnus);
 
    $stmt->execute();
    $lukumaara = $stmt->rowCount();
    
	if ($lukumaara  === 0)
    {
        die('Kirjautumistiedot virheelliset.');
    }
	if ($lukumaara  > 1)
    {
        die('Haettavia käyttäjiä useampi kuin yksi.');
    }
	// haetaan löytyneen käyttäjän tiedot $rivi-nimiseen taulukkoon
	$rivi = $stmt->fetch(PDO::FETCH_ASSOC);
    $salasana = $rivi["kayttajaSalasana"];
	$kayttajaTunnus = $rivi["kayttajaTunnus"];

	// if (tietokannasta löytynyt salasana on eri suuri kuin käyttäjän selaimeen antama
	if ($salasana !== $kayttajaSalasana)
    {   
	    die("Kirjautumistiedot virheelliset.");
    }
	
    $nimi = $kayttajaTunnus; 
    echo $nimi; 
	$_SESSION['kNimi'] = $nimi;  
   
  }
 
// show error
catch(PDOException $exception)
  {
    die('Virhe ohjelmointikoodissa: ' . $exception->getMessage());
  }
?>
