<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>
<head>
 <meta charset="UTF-8">
<title>jQuery, AJAX ja PHP-koodilla kirjaudutaan sisään</title>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>

</head>
<body>

<p id="kayttajaNimi">Käyttäjä ei ole kirjautunut</p><br>

<div id="logInTiedot" hidden>
Käyttäjän tunnus:<input type="text" id="kayttajaTunnus" value=""><br>
Käyttäjän salasana:<input type="password" id="kayttajaSalasana" value="Fingerpori!" ><br>
<button id="kirjaudu">Kirjaudu sisään</button>
</div>

<script>
$("#kirjaudu" ).click(function() {
var kayttajaTunnus = $("#kayttajaTunnus").val();
var kayttajaSalasana = $("#kayttajaSalasana").val();

   $.ajax({

          url: 'HaeKayttajaNimiTietokannasta.php', 
          data: {kayttajaTunnus: kayttajaTunnus, kayttajaSalasana: kayttajaSalasana},
		  type: "POST",
		  
		  dataType: 'text', 
 	      
          success: function(vastaus) 
		  { 
			 // siirretään tekstimuotoinen vastaus käyttäjän nimi -kenttään 
			 // jos kenttä olisi input-type, niin $("#kayttajaNimi").val(vastaus);
			 $("#kayttajaNimi").html(vastaus );
			 
			 if ( vastaus !== "Kirjautumistiedot virheelliset.")
			 {
			 // koska login on tehty, voidaan piilottaa kirjautumistiedot
			 $("#logInTiedot").hide();	
			 // success-osaan laitetaan hyppy uudelle sivulle, jos kirjautumisen jälkeen siirrytään ...	  
			 window.location.assign("Etusivu.php");

			 }

			 
		  }	 
   });

  
});
</script>

<script>

$(document).ready(function(){
// paragraph-tagissa oleva tieto luetaan muuttujaan kirjautumisTieto
var kirjautumisTieto = $("#kayttajaNimi").html();
if (kirjautumisTieto == "Käyttäjä ei ole kirjautunut")
{
   // käyttäjä ei ole tunnistautunut
   $("#logInTiedot").show();
}
});

</script>

</body>
</html>
